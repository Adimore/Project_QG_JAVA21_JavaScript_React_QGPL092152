package io.capgemini.fooddelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodDeliveryApp1ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
